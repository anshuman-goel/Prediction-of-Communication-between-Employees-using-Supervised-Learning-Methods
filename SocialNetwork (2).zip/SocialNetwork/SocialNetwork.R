##############################################################################
#
#Social Network Prediction on Enron Email dataset
# CSC-522 Project
#
# By:
# Anshuman Goel - agoel5
# Rohit Nambisam - rnambis
# Tyler Cannon - tjcannon
#
##############################################################################

#Installing Naive Bayesian Package e1071 saved on local machine

#install.packages("E:\\NCSU\\Semester 1\\Automated Learning and Data Analysis\\Project\\Enron\\e1071_1.6-7.zip", repos = NULL, type="source")

#Loading Library
library(e1071)

#Loading the dataset
locations_path = file.choose()
dat <- read.csv(locations_path, header = TRUE);

#Reading in Date Format
date<-strptime(dat[,4],format='%d %b %Y %H:%M:%S %z')

#Building new corrected data frame
data<-data.frame(dat[,1],date,dat[,2])
rm(dat)

#Sampling Data
#Change size of sample when actual data is ready
set.seed(123)
train <- data[sample(seq_len(nrow(data)), size = 7), ]
test <- data[sample(seq_len(nrow(data)), size = 2), ]

#To freeup RAM
rm(data)

#Building Naive Bayesian Model on training data
model<-naiveBayes(train[,1],train[,3])

#Initializing variable
correct_nb<-0

#Testing model with test data and Calculating Accuracy
for (i in 1:nrow(test)) {
  pred<-predict(model, test[i,1])
  if(pred==test[i,3])
    correct_nb<-correct_nb+1
}

#Accuracy of Naive Bayesian Model
print(c('Accuracy of Naive Bayesian Model is : ',correct_nb/nrow(test)))

#Removing Variables
rm(i,pred,model)

#Installing Package
#install.packages("igraph")

#Loading the igraph library
library(igraph)

#Making Adjacency Matrix of Training data
m <- as.matrix(train[,c(1,3)])
adj_list<-get.adjacency(graph.edgelist(cbind(m[, 1], c(m[, -1]))),sparse=FALSE)

#Plotting graph
g <- graph.adjacency(adj_list, weighted=T, mode = 'directed')
set.seed(3952)
layout1 <- layout.fruchterman.reingold(g)
plot(g, layout=layout1)

#Different and interactive type of graph
#tkplot(g, layout=layout.kamada.kawai)

#Removing unnecessary variables
rm(g,layout1)

#Installing packages for graph links prediction 
#& considering proxy package is already installed
#install.packages('statnet')

#Loading libraries
library(sna)
library(proxy)

#Predicting Graph and edges and selecting the best threshold
#Assigning Initial threshold to be -infinity
threshold<-Inf
prev_pred<-0
#Applying Leave one out Cross Validation
for (i in 1:nrow(train)) {
  #Building Adjacency Matrix
  if(i==1)
  {
    m <- as.matrix(train[2:nrow(train),c(1,3)])
  }
  else if(i==nrow(train))
  {
    m <- as.matrix(train[1:nrow(train)-1,c(1,3)])
  }
  else
  {
    k1<-i-1
    k2<-i+1
    m <- as.matrix(train[c(1:k1,k2:nrow(train)),c(1,3)])
  }
  el <- cbind(m[, 1], c(m[, -1]))
  adj_list<-get.adjacency(graph.edgelist(el),sparse=FALSE)
  
  #Calculating distances between two vertices of graph
  #using proxy package measure
  predval<-dist(adj_list)
  max_value<-ceiling(max(predval))
  min_value<-floor(min(predval))
  increment_by<-(max_value-min_value)/10
  k<-max_value

  while (k>=min_value) {
    pred<-0
    adjmatrix<-(as.matrix(predval)>k)
    diag(adjmatrix)<-FALSE
    adjmatrix[adjmatrix==TRUE]<-1
    adjmatrix[lower.tri(adjmatrix)] <- 0
    #Comparing predicted edges with testing data
    for (p in 1:nrow(adjmatrix)) {
      for (q in p:ncol(adjmatrix)) {
        if(adjmatrix[p,q]==1){
          for (r in 1:nrow(test)) {
            #Accuracy at the given threshold
            if(rownames(adjmatrix)[p]==test[r,1] && colnames(adjmatrix)[q]==test[r,3])
            {
              pred<-pred+1
            }
          }
        }
      }
    }
    #Selecting Best and maximum threshold
    if(prev_pred<pred && threshold>k)
    {
      threshold<-k
      prev_pred<-pred
    }
    k<-k-increment_by
  }

}

#Variable threshold contains the best selected threshold

#Removing Unnecessay Variables
#rm(k1,k2,adj_list,adjmatrix,el,m,i,k,increment_by,max_value,min_value)
#rm(p,q,r,pred,predval,prev_pred)

#Initailizing variables for calculating accuracy
correct<-0
incorrect<-0

#Calculating the Accuracy of the model
for (i in 1:nrow(train)) {
  #Building Adjacency Matrix
  if(i==1)
  {
    m <- as.matrix(train[2:nrow(train),c(1,3)])
  }
  else if(i==nrow(train))
  {
    m <- as.matrix(train[1:nrow(train)-1,c(1,3)])
  }
  else
  {
    k1<-i-1
    k2<-i+1
    m <- as.matrix(train[c(1:k1,k2:nrow(train)),c(1,3)])
  }
  el <- cbind(m[, 1], c(m[, -1]))
  adj_list<-get.adjacency(graph.edgelist(el),sparse=FALSE)
  adjmatrix<-(as.matrix(dist(adj_list))>threshold)
  diag(adjmatrix)<-FALSE
  adjmatrix[adjmatrix==TRUE]<-1
  adjmatrix[lower.tri(adjmatrix)] <- 0
  k<-FALSE
  for (p in 1:nrow(adjmatrix)) {
    for (q in p:ncol(adjmatrix)) {
      if(adjmatrix[p,q]==1)
      {
        if( rownames(adjmatrix)[p]==train[i,1] && colnames(adjmatrix)[q]==train[i,3])
         k<-TRUE
      }
    }
  }
  if(k<-TRUE)
    correct<-correct+1
  else
    incorrect<-incorrect+1
}

print(c('Accuracy is :',correct/nrow(train)))